package Exercicio2_1;

public class ExecutarNome {

	public static void main(String[] args) {
		FormarNome fn = new FormarNome();
		
		String nome = "Jessica";
		String sobrenome = "Andrade";
		
		fn.getNome(nome, sobrenome);

	}

}