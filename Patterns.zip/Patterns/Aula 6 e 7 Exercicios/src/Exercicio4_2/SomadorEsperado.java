package Exercicio4_2;

public interface SomadorEsperado {
	int somaVetor(int[] vetor);
}
