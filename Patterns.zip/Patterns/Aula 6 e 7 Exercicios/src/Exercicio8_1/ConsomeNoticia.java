package Exercicio8_1;

public interface ConsomeNoticia {     
	public void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
} 


