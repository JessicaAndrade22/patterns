package exercicio_1_2;

public interface Calzone extends Produto {

}
