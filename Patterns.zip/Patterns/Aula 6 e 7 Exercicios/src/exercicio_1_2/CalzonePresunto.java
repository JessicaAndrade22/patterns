package exercicio_1_2;

public class CalzonePresunto implements Calzone{

	@Override
	public void printIngredientes() {
		System.out.println("Calzone de Presunto - Ingrediente: Queijo, Presunto e Tomate");		
	}

}
