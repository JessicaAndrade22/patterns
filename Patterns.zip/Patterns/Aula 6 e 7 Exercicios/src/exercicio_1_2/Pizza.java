package exercicio_1_2;

public interface Pizza extends Produto {
}
