package exercicio_1_2;

public class PizzariaFechada implements Produto {

	@Override
	public void printIngredientes() {
		System.out.println("Pizzaria Fechada");		
	}
}
