package exercicio_1_2;

public interface Produto {	
	void printIngredientes();
}
