package Exercicio6_2;

public interface SelectionSort {
	void sort(double[] a);
}
