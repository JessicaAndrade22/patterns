package Exercicio8_2;

public abstract class Noticiario {
	public abstract void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
}
