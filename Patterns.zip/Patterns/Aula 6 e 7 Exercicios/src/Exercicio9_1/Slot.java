package Exercicio9_1;



public interface Slot {
	public double recebeMoeda(int m);
	public void setSlot(Slot s);
}
