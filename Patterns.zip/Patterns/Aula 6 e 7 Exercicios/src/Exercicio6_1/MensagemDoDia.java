package Exercicio6_1;

public interface MensagemDoDia {
	void imprimir();
}
